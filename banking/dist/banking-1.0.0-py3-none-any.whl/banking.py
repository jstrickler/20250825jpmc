"""
Module documentation...
"""



def sample_function(*args):
    """
    Sample function documentation...
    """
    print("sample banking function")



class Banking:
    """
    Class documentation...
    """

    def sample_method(self):
        """
        Sample method documentation...
        """
        print("sample Banking instance method")



if __name__ == "__main__":
    # the code in this block (and all the code above) will be run when
    # either
    #    python banking.py
    # or 
    #    python -m banking
    # is executed, but NOT when imported like
    #    import banking
    print(f"Hello from {__file__}")
